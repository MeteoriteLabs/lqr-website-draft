"use client"
import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { CreateCustomize } from "@/components/create-customize"
import { ShareQR } from "@/components/share-qr"
import { TrackEngage } from "@/components/track-engage"
import { ReferEarn } from "@/components/refer-earn"
import { WhoIsFor } from "@/components/who-is-for"
import { Testimonials } from "@/components/testimonials"
import { FAQ } from "@/components/faq"
import { FinalCTA } from "@/components/final-cta"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <CreateCustomize />
        <ShareQR />
        <TrackEngage />
        <ReferEarn />
        <WhoIsFor />
        <Testimonials />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  )
}
