"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"

export function Hero() {
  return (
    <section className="bg-[#1B3B1A] text-white min-h-screen flex items-center pt-16 lg:pt-20 relative overflow-hidden">
      {/* Background World Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/vintage-world-map.svg')] bg-no-repeat bg-center bg-cover opacity-[0.08]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <motion.div
            className="text-center lg:text-left"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.h1
              className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              All your recommendations in one simple QR and link.
            </motion.h1>

            <motion.p
              className="text-xl lg:text-2xl text-green-100 mb-8 leading-relaxed"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              Turn your knowledge of a place into a shareable guide — engage your followers, customers, travelers, and
              friends alike.
            </motion.p>

            {/* URL Input */}
            <motion.div
              className="bg-white rounded-lg p-2 flex flex-col sm:flex-row gap-2 mb-8 max-w-lg mx-auto lg:mx-0"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <div className="flex-1 flex items-center px-3 py-2 text-gray-600">
                <span className="text-sm">localqr.earth/</span>
                <Input
                  placeholder="yourname"
                  className="border-0 shadow-none focus-visible:ring-0 p-0 text-gray-900 placeholder:text-gray-400"
                />
              </div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 w-full sm:w-auto">
                  Claim Your LocalQR
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 1 }}
          >
            <div className="relative aspect-square max-w-md mx-auto">
              <Image
                src="/placeholder.svg?height=500&width=500"
                alt="Person scanning QR code on mobile phone"
                fill
                className="object-cover rounded-2xl shadow-2xl"
              />
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-green-900/20 to-transparent rounded-2xl"
                animate={{ opacity: [0.5, 0.8, 0.5] }}
                transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
