"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function FinalCTA() {
  return (
    <section className="bg-[#0066FF] py-16 lg:py-24 relative overflow-hidden">
      {/* Background Compass Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/compass-map-outline.svg')] bg-no-repeat bg-center bg-cover opacity-[0.08]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center lg:text-left"
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Start sharing your world today
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Claim your free LocalQR and turn your local insights into shareable guides.
            </p>

            <motion.div
              whileHover={{
                scale: 1.05,
                boxShadow: "0 20px 40px rgba(255, 255, 255, 0.3)",
              }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <Button
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-12 py-4 text-xl font-semibold shadow-lg"
              >
                Claim Your LocalQR – Free Forever
              </Button>
            </motion.div>
          </motion.div>

          <motion.div
            className="relative"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-square max-w-sm mx-auto">
              <Image
                src="/placeholder.svg?height=400&width=400"
                alt="QR code mockup"
                fill
                className="object-cover rounded-2xl shadow-2xl"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
