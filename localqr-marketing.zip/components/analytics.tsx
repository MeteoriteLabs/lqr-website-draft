"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { BarChart3, Eye, TrendingUp } from "lucide-react"
import Image from "next/image"

const analytics = [
  {
    icon: Eye,
    title: "See what's working",
    description: "Track which places get the most love",
  },
  {
    icon: BarChart3,
    title: "Who's scanning",
    description: "Real-time engagement metrics",
  },
  {
    icon: TrendingUp,
    title: "Top-performing spots",
    description: "Data-driven insights for better curation",
  },
]

export function Analytics() {
  return (
    <section className="bg-[#1A2B49] text-white py-16 lg:py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <motion.div
            className="relative order-2 lg:order-1"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Analytics UI showing graphs and performance metrics"
                fill
                className="object-cover"
              />
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            className="order-1 lg:order-2"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              Track clicks, referrals, and top-performing spots
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              See what's working, who's scanning, and which places get the most love — in real time.
            </p>

            <div className="space-y-6 mb-8">
              {analytics.map((item, index) => (
                <motion.div
                  key={item.title}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <item.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{item.title}</h3>
                    <p className="text-blue-100">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg">View Analytics</Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
