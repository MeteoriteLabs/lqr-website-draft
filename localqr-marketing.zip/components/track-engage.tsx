"use client"

import { motion } from "framer-motion"
import { BarChart3, Eye, TrendingUp } from "lucide-react"
import Image from "next/image"

const analytics = [
  {
    icon: Eye,
    title: "See which places get the most love",
    description: "Track popularity of your recommendations",
  },
  {
    icon: BarChart3,
    title: "Monitor QR scans and updates",
    description: "Real-time engagement metrics",
  },
  {
    icon: TrendingUp,
    title: "Optimize your recommendations",
    description: "Data-driven insights for better curation",
  },
]

export function TrackEngage() {
  return (
    <section className="bg-[#1A2B49] text-white py-16 lg:py-24 relative overflow-hidden">
      {/* Background World Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/vintage-world-map.svg')] bg-no-repeat bg-center bg-cover opacity-[0.08]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <motion.div
            className="relative order-2 lg:order-1"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Analytics dashboard showing QR code performance"
                fill
                className="object-cover"
              />
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            className="order-1 lg:order-2"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">Track clicks, referrals, and engagement</h2>

            <div className="space-y-6 mb-0">
              {analytics.map((item, index) => (
                <motion.div
                  key={item.title}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <item.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{item.title}</h3>
                    <p className="text-blue-100">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
