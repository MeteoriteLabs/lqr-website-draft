"use client"

import { motion } from "framer-motion"
import { MapPin, Layers, Zap } from "lucide-react"
import Image from "next/image"

const features = [
  {
    icon: MapPin,
    title: "Add your favorite spots",
    description: "Curate a list of your must-visit places",
  },
  {
    icon: Layers,
    title: "Organize them by city or theme",
    description: "Create categories that make sense for your audience",
  },
  {
    icon: Zap,
    title: "Generate your QR instantly",
    description: "Your personalized QR code is ready in seconds",
  },
]

export function CreateCustomize() {
  return (
    <section className="bg-[#FAFAF7] py-16 lg:py-24 relative">
      {/* Background Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/grayscale-street-map.svg')] bg-no-repeat bg-center bg-cover opacity-[0.07]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <motion.div
            className="relative order-2 lg:order-1"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Dashboard screenshot showing LocalQR creation interface"
                fill
                className="object-cover"
              />
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            className="order-1 lg:order-2"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2E2E2E] mb-4">
              Create and customize your LocalQR in minutes
            </h2>
            <p className="text-lg text-[#555555] mb-8">
              Add your favorite spots, organize them by city or theme, and generate your QR instantly.
            </p>

            <div className="space-y-6 mb-8">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-[#2E2E2E] mb-1">{feature.title}</h3>
                    <p className="text-[#555555]">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
