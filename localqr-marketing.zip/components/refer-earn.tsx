"use client"

import { motion } from "framer-motion"
import { DollarSign, Users, Gift } from "lucide-react"
import Image from "next/image"

const benefits = [
  {
    icon: DollarSign,
    title: "Turn recommendations into passive rewards",
    description: "Monetize your local knowledge effortlessly",
  },
  {
    icon: Users,
    title: "Get credit when others use your QR",
    description: "Build your network and earn automatically",
  },
  {
    icon: Gift,
    title: "Referral rewards program",
    description: "Share LocalQR and earn for every signup",
  },
]

export function ReferEarn() {
  return (
    <section className="bg-[#471919] text-white py-16 lg:py-24 relative overflow-hidden">
      {/* Background World Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/vintage-world-map.svg')] bg-no-repeat bg-center bg-cover opacity-[0.08]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">Share, refer, and earn</h2>
            <p className="text-xl text-red-100 mb-8">
              Turn your recommendations into passive rewards — get credit when others use your QR.
            </p>

            <div className="space-y-6 mb-0">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <benefit.icon className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{benefit.title}</h3>
                    <p className="text-red-100">{benefit.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Coin icon and referral dashboard interface"
                fill
                className="object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
