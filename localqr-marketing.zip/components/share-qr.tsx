"use client"

import { motion } from "framer-motion"
import { Instagram, Coffee, BookOpen } from "lucide-react"
import Image from "next/image"

const shareOptions = [
  {
    icon: Instagram,
    title: "Add to your Instagram bio",
    description: "Share with your followers",
  },
  {
    icon: Coffee,
    title: "Stick on a coffee cup",
    description: "Physical world sharing",
  },
  {
    icon: BookOpen,
    title: "Include in guest welcome books",
    description: "Perfect for hosts",
  },
]

export function ShareQR() {
  return (
    <section className="bg-[#4B2E1D] text-white py-16 lg:py-24 relative overflow-hidden">
      {/* Background World Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/vintage-world-map.svg')] bg-no-repeat bg-center bg-cover opacity-[0.08]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Share it on your socials, storefront, or city wall
            </h2>

            <div className="space-y-6 mb-0">
              {shareOptions.map((option, index) => (
                <motion.div
                  key={option.title}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                    <option.icon className="w-6 h-6 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{option.title}</h3>
                    <p className="text-amber-100">{option.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="QR codes on various surfaces - paper, glass, screen"
                fill
                className="object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
