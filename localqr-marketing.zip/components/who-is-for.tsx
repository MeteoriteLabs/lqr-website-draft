"use client"

import { motion } from "framer-motion"
import { Plane, Users, Home, Building, UtensilsCrossed, Coffee, MapPin, Palette, Bus, Briefcase } from "lucide-react"

const personas = [
  {
    icon: Plane,
    title: "Travelers",
    description: "Discover hidden gems and local favorites",
  },
  {
    icon: Users,
    title: "Influencers",
    description: "Share curated recommendations with followers",
  },
  {
    icon: Home,
    title: "Airbnb Hosts",
    description: "Help guests explore like locals",
  },
  {
    icon: Building,
    title: "Hotels",
    description: "Enhance guest experience with local insights",
  },
  {
    icon: UtensilsCrossed,
    title: "Restaurants",
    description: "Recommend nearby attractions and activities",
  },
  {
    icon: Coffee,
    title: "Cafes",
    description: "Build community connections",
  },
  {
    icon: MapPin,
    title: "Local Guides",
    description: "Share insider knowledge with visitors",
  },
  {
    icon: Palette,
    title: "Creators",
    description: "Integrate local guides into your brand",
  },
  {
    icon: Bus,
    title: "Tour Operators",
    description: "Extend tours with personalized recommendations",
  },
  {
    icon: Briefcase,
    title: "Any Business",
    description: "Connect with customers through local insights",
  },
]

export function WhoIsFor() {
  return (
    <section className="bg-[#F5F8F3] py-16 lg:py-24 relative">
      {/* Background Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/grayscale-street-map.svg')] bg-no-repeat bg-center bg-cover opacity-[0.07]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2E2E2E] mb-4">Who is LocalQR for?</h2>
          <p className="text-lg text-[#555555] max-w-3xl mx-auto">
            LocalQR fits the needs of explorers, entrepreneurs, and everyday locals — all in one scannable link.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {personas.map((persona, index) => (
            <motion.div
              key={persona.title}
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <persona.icon className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-[#2E2E2E] mb-2">{persona.title}</h3>
              <p className="text-[#555555] text-sm">{persona.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
