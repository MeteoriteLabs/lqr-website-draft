"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Instagram, Coffee, BookOpen } from "lucide-react"
import Image from "next/image"

const shareOptions = [
  {
    icon: Instagram,
    title: "Add it to your Instagram bio",
    description: "Share with your followers instantly",
  },
  {
    icon: Coffee,
    title: "Print it on menus",
    description: "Physical world sharing made easy",
  },
  {
    icon: BookOpen,
    title: "Include in welcome books",
    description: "Perfect for hosts and guides",
  },
]

export function ShareAnywhere() {
  return (
    <section className="bg-[#4B2E1D] text-white py-16 lg:py-24 relative overflow-hidden">
      {/* Background SVG Accents */}
      <div className="absolute inset-0 opacity-10">
        <svg className="absolute top-10 right-10 w-28 h-28" viewBox="0 0 100 100" fill="currentColor">
          <rect x="10" y="10" width="80" height="80" rx="5" fill="none" stroke="currentColor" strokeWidth="2" />
          <rect x="20" y="20" width="60" height="60" rx="3" fill="currentColor" />
          <circle cx="50" cy="50" r="15" fill="none" stroke="white" strokeWidth="2" />
        </svg>
        <svg
          className="absolute bottom-20 left-10 w-32 h-16"
          viewBox="0 0 200 100"
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
        >
          <path d="M20 50 L40 30 L60 50 L80 30 L100 50 L120 30 L140 50 L160 30 L180 50" />
          <circle cx="50" cy="40" r="4" fill="currentColor" />
          <circle cx="100" cy="40" r="4" fill="currentColor" />
          <circle cx="150" cy="40" r="4" fill="currentColor" />
        </svg>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              Share it on your socials, storefront, or guest kit
            </h2>
            <p className="text-xl text-amber-100 mb-8">
              Add it to your Instagram bio, print it on menus, or include in welcome books — your guide, always ready.
            </p>

            <div className="space-y-6 mb-8">
              {shareOptions.map((option, index) => (
                <motion.div
                  key={option.title}
                  className="flex items-start space-x-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                    <option.icon className="w-6 h-6 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{option.title}</h3>
                    <p className="text-amber-100">{option.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 text-lg">Get Started</Button>
            </motion.div>
          </motion.div>

          {/* Image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="QR sticker on storefront and printed menu"
                fill
                className="object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
