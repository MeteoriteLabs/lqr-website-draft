"use client"

import { motion } from "framer-motion"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion"

const faqs = [
  {
    question: "What is LocalQR?",
    answer:
      "LocalQR is a platform that helps you create personalized QR codes containing your location-based recommendations. Share your favorite cafes, museums, hideaways, and more through a simple QR code or shortlink that engages your followers, customers, travelers, and friends.",
  },
  {
    question: "Is it free?",
    answer:
      "Yes! LocalQR offers a free forever plan that includes basic features like creating your QR code, adding recommendations, and basic analytics. We also offer premium plans with advanced features for power users and businesses.",
  },
  {
    question: "Can I update my recommendations?",
    answer:
      "You can update your recommendations, add new places, reorganize categories, and modify your LocalQR content anytime. Your QR code stays the same, but the content behind it can be updated instantly, so your audience always gets the latest information.",
  },
  {
    question: "How do I share my QR?",
    answer:
      "You can share your LocalQR in multiple ways: download the QR code image for printing, share the shortlink on social media, embed it in your website, add it to your email signature, print it on business cards, or include it in welcome kits. The possibilities are endless!",
  },
  {
    question: "Can businesses use this?",
    answer:
      "Definitely! LocalQR is perfect for businesses like restaurants, hotels, cafes, tour operators, Airbnb hosts, and any business that wants to share local recommendations with customers. We offer business features, analytics, and referral programs to help you track engagement and earn rewards.",
  },
]

export function FAQ() {
  return (
    <section id="faq" className="bg-[#E6ECE6] py-16 lg:py-24 relative">
      {/* Background Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/grayscale-street-map.svg')] bg-no-repeat bg-center bg-cover opacity-[0.07]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl relative z-10">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2E2E2E] mb-4">Got questions?</h2>
          <p className="text-lg text-[#555555]">
            We've answered the most common things people ask before getting started.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <AccordionItem
                  value={`item-${index}`}
                  className="bg-white rounded-lg shadow-sm border-0 overflow-hidden"
                >
                  <AccordionTrigger className="px-6 py-4 text-left font-semibold text-[#2E2E2E] hover:no-underline hover:bg-gray-50 transition-colors duration-200">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-4 text-[#555555] leading-relaxed">{faq.answer}</AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  )
}
