"use client"

import * as React from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown } from "lucide-react"
import { cn } from "../../lib/utils"

interface AccordionContextType {
  openItems: string[]
  toggleItem: (value: string) => void
  type: "single" | "multiple"
}

const AccordionContext = React.createContext<AccordionContextType | undefined>(undefined)

interface AccordionProps {
  type: "single" | "multiple"
  collapsible?: boolean
  className?: string
  children: React.ReactNode
}

const Accordion = React.forwardRef<HTMLDivElement, AccordionProps>(
  ({ className, type, collapsible = false, children, ...props }, ref) => {
    const [openItems, setOpenItems] = React.useState<string[]>([])

    const toggleItem = React.useCallback(
      (value: string) => {
        setOpenItems((prev) => {
          if (type === "single") {
            if (prev.includes(value)) {
              return collapsible ? [] : prev
            }
            return [value]
          } else {
            if (prev.includes(value)) {
              return prev.filter((item) => item !== value)
            }
            return [...prev, value]
          }
        })
      },
      [type, collapsible],
    )

    return (
      <AccordionContext.Provider value={{ openItems, toggleItem, type }}>
        <motion.div
          ref={ref}
          className={className}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          {...props}
        >
          {children}
        </motion.div>
      </AccordionContext.Provider>
    )
  },
)
Accordion.displayName = "Accordion"

interface AccordionItemProps {
  value: string
  className?: string
  children: React.ReactNode
}

const AccordionItem = React.forwardRef<HTMLDivElement, AccordionItemProps>(
  ({ className, value, children, ...props }, ref) => {
    return (
      <motion.div
        ref={ref}
        className={cn("border-b", className)}
        data-value={value}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        {...props}
      >
        {children}
      </motion.div>
    )
  },
)
AccordionItem.displayName = "AccordionItem"

interface AccordionTriggerProps {
  className?: string
  children: React.ReactNode
}

const AccordionTrigger = React.forwardRef<HTMLButtonElement, AccordionTriggerProps>(
  ({ className, children, ...props }, ref) => {
    const context = React.useContext(AccordionContext)
    const itemElement = React.useContext(AccordionItemContext)

    if (!context || !itemElement) {
      throw new Error("AccordionTrigger must be used within AccordionItem")
    }

    const { openItems, toggleItem } = context
    const { value } = itemElement
    const isOpen = openItems.includes(value)

    return (
      <div className="flex">
        <motion.button
          ref={ref}
          className={cn(
            "flex flex-1 items-center justify-between py-4 font-medium transition-all hover:underline",
            className,
          )}
          onClick={() => toggleItem(value)}
          aria-expanded={isOpen}
          data-state={isOpen ? "open" : "closed"}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          {...props}
        >
          <span>{children}</span>
          <motion.div animate={{ rotate: isOpen ? 180 : 0 }} transition={{ duration: 0.3, ease: "easeInOut" }}>
            <ChevronDown className="h-4 w-4 shrink-0" />
          </motion.div>
        </motion.button>
      </div>
    )
  },
)
AccordionTrigger.displayName = "AccordionTrigger"

interface AccordionContentProps {
  className?: string
  children: React.ReactNode
}

const AccordionItemContext = React.createContext<{ value: string } | undefined>(undefined)

const AccordionContent = React.forwardRef<HTMLDivElement, AccordionContentProps>(
  ({ className, children, ...props }, ref) => {
    const context = React.useContext(AccordionContext)
    const itemElement = React.useContext(AccordionItemContext)

    if (!context || !itemElement) {
      throw new Error("AccordionContent must be used within AccordionItem")
    }

    const { openItems } = context
    const { value } = itemElement
    const isOpen = openItems.includes(value)

    return (
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            ref={ref}
            className="overflow-hidden"
            initial={{ height: 0, opacity: 0 }}
            animate={{
              height: "auto",
              opacity: 1,
              transition: {
                height: { duration: 0.4, ease: "easeInOut" },
                opacity: { duration: 0.3, delay: 0.1 },
              },
            }}
            exit={{
              height: 0,
              opacity: 0,
              transition: {
                height: { duration: 0.3, ease: "easeInOut" },
                opacity: { duration: 0.2 },
              },
            }}
            data-state={isOpen ? "open" : "closed"}
            {...props}
          >
            <motion.div
              className={cn("pb-4 pt-0", className)}
              initial={{ y: -10 }}
              animate={{ y: 0 }}
              exit={{ y: -10 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
            >
              {children}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    )
  },
)
AccordionContent.displayName = "AccordionContent"

// Enhanced AccordionItem with context
const EnhancedAccordionItem = React.forwardRef<HTMLDivElement, AccordionItemProps>(
  ({ value, children, ...props }, ref) => {
    return (
      <AccordionItemContext.Provider value={{ value }}>
        <AccordionItem ref={ref} value={value} {...props}>
          {children}
        </AccordionItem>
      </AccordionItemContext.Provider>
    )
  },
)
EnhancedAccordionItem.displayName = "AccordionItem"

export { Accordion, EnhancedAccordionItem as AccordionItem, AccordionTrigger, AccordionContent }
