"use client"

import { motion } from "framer-motion"
import { Button } from "./ui/button"

export function FinalCTA() {
  const scrollToHero = () => {
    const element = document.getElementById("hero")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="claim-qr" className="bg-[#0066FF] py-16 lg:py-24 relative overflow-hidden">
      {/* Background Compass Map Pattern */}
      <div
        className="absolute inset-0 bg-[url('/compass-map-outline.svg')] bg-no-repeat bg-center bg-cover opacity-[0.08]"
        aria-hidden="true"
      />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center lg:text-left order-2 lg:order-1"
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Start sharing your world today
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Claim your free LocalQR and turn your local insights into shareable guides.
            </p>

            <motion.div
              className="inline-block"
              whileHover={{
                scale: 1.02,
              }}
              whileTap={{ scale: 0.98 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <Button
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-8 lg:px-12 py-3 lg:py-4 text-lg lg:text-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 w-full sm:w-auto"
                onClick={scrollToHero}
              >
                Claim Your LocalQR – Free Forever
              </Button>
            </motion.div>
          </motion.div>

          {/* Image */}
          <motion.div
            className="relative order-1 lg:order-2"
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="relative aspect-square max-w-xs sm:max-w-sm mx-auto">
              <img
                src="/placeholder.svg?height=400&width=400"
                alt="QR code mockup"
                className="w-full h-full object-cover rounded-2xl shadow-2xl"
              />
              {/* Subtle glow effect instead of harsh shadow */}
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/10 to-transparent rounded-2xl pointer-events-none" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
