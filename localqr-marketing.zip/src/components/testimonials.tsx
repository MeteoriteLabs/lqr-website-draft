"use client"

import { motion } from "framer-motion"

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Airbnb Host, Tokyo",
    avatar: "/placeholder.svg?height=60&width=60",
    quote:
      "I use it in every welcome kit I send my guests. They love having local recommendations at their fingertips!",
    rating: 5,
  },
  {
    name: "Marcus Rodriguez",
    role: "Travel Blogger, Barcelona",
    avatar: "/placeholder.svg?height=60&width=60",
    quote:
      "LocalQR has transformed how I share my travel discoveries. My followers can't get enough of my curated city guides.",
    rating: 5,
  },
  {
    name: "Emma Thompson",
    role: "Cafe Owner, Portland",
    avatar: "/placeholder.svg?height=60&width=60",
    quote:
      "Our customers love scanning our QR to discover other great spots in the neighborhood. It's built amazing community connections.",
    rating: 5,
  },
  {
    name: "David Park",
    role: "Hotel Manager, Seoul",
    avatar: "/placeholder.svg?height=60&width=60",
    quote:
      "We've added LocalQR codes to every room keycard. Guest satisfaction scores have increased significantly since implementation.",
    rating: 5,
  },
  {
    name: "Lisa Wang",
    role: "Local Guide, San Francisco",
    avatar: "/placeholder.svg?height=60&width=60",
    quote:
      "My walking tour participants always ask for my recommendations. Now I just share my LocalQR and they have everything they need.",
    rating: 5,
  },
]

export function Testimonials() {
  return (
    <section className="bg-[#2E2E2E] text-white py-16 lg:py-24 overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">Loved by travelers, creators, and hosts</h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            See how people around the world use LocalQR to share what matters most.
          </p>
        </motion.div>

        {/* Horizontal Scroll Container */}
        <div className="relative">
          <motion.div
            className="flex space-x-6 pb-4"
            drag="x"
            dragConstraints={{ left: -1000, right: 0 }}
            initial={{ x: 0 }}
            animate={{ x: -200 }}
            transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          >
            {[...testimonials, ...testimonials].map((testimonial, index) => (
              <motion.div
                key={`${testimonial.name}-${index}`}
                className="flex-shrink-0 w-80 bg-white rounded-xl p-6"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                <div className="flex items-center mb-4">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden mr-4">
                    <img
                      src={testimonial.avatar || "/placeholder.svg"}
                      alt={testimonial.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-gray-600 text-sm">{testimonial.role}</p>
                  </div>
                </div>

                <p className="text-gray-700 leading-relaxed">"{testimonial.quote}"</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
